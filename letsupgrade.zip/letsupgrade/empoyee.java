
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class empoyee {
    
public static Scanner sc;
public static int getAge(LocalDate dob){
    LocalDate curDate = LocalDate.now();
    return Period.between(dob, curDate).getYears();
}

     public static void main(String[] args) {
         String name;
         int montylysallary;
         int Annualsalary;
         double tax = 0;

          sc = new Scanner(System.in);
         System.out.println("Enter the Emplyee name:");
         name = sc.nextLine();
         System.out.println("\n employee name is " + name );
         System.out.println("\nEnter the date of birth YYY-MM-DD: ");
         String input = sc.nextLine();
         

         LocalDate dob = LocalDate.parse(input);
         System.out.println(" Age is:" + getAge(dob));
         
         System.out.println("\nPlease enter your Monthly salary");
         montylysallary = sc.nextInt();
        
         Annualsalary = montylysallary * 12;
         System.out.println(" \n Anual salary is " + Annualsalary);
         
         if (Annualsalary >= 500000){
             tax = Annualsalary*0.2;
         } else if (Annualsalary >= 400000 && Annualsalary < 5000000){
             tax = Annualsalary *0.15;
         } else if (Annualsalary >= 300000 && Annualsalary <= 4000000){
             tax = Annualsalary *0.1;
         } else if (Annualsalary >= 200000 && Annualsalary <= 300000){
             tax = Annualsalary *0.5;
         } else{
             tax = 0;
         }
       System.out.println("  \n Tax ammount is: "  + tax);  

    }
    
}

import java.util.Scanner;

public class student {   
    public static Scanner sc;
     public static void main(String[] args) {
            
         
        int maths ;
        int Physics;
        int Chemistry;
        int Biology;
        int Computer;
        float total, percentage;
        
         sc = new Scanner(System.in);
        System.out.println("Enter the 5 subject marks");
        maths =sc.nextInt();
        Physics = sc.nextInt();
        Chemistry = sc.nextInt();
        Biology = sc.nextInt();
        Computer = sc.nextInt();
        
        total = maths + Physics + Chemistry + Biology + Computer;
        percentage = (total/500) * 100;
        System.out.println("\nStudent percentage is " + percentage );
        
        if (percentage >= 80){
            System.out.println("Student grade A");
        }
        else if (percentage >= 60 && percentage < 80){
            System.out.println("student grade B");
        }
        else if(percentage >= 40 && percentage < 60){
            System.out.println("Student grade is C");

        }
        else{
            System.out.println("Student is fail");
        }

        
    }
}
